package com.metricas.metricas;

import androidx.appcompat.app.AppCompatActivity;

import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.metricas.metricas.BD.conexion;
import com.metricas.metricas.control.DAO;
import com.metricas.metricas.control.service;

import java.util.ArrayList;

public class verBDActivity extends AppCompatActivity {

    public static conexion conexion;

    ListView mostrarDatos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ver_b_d);

        conexion = new conexion(this, "metricas", null, 1);
        mostrarDatos = (ListView) findViewById(R.id.datosCapturados);
        service service = new service();
        service.consultar(conexion);


        ArrayAdapter adaptador = new ArrayAdapter(this, android.R.layout.simple_list_item_1, DAO.listaInformacion);
        mostrarDatos.setAdapter(adaptador);

        mostrarDatos.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String informacion="id: "+DAO.listaMetricas.get(position).getIdMetrica()+"\n";
                informacion+="n1: "+DAO.listaMetricas.get(position).getCantidadOperadores()+"\n";
                informacion+="n2: "+DAO.listaMetricas.get(position).getCantidadOperandos()+"\n";
                informacion+="N1: "+DAO.listaMetricas.get(position).getOcurrenciasOperadores()+"\n";
                informacion+="N2: "+DAO.listaMetricas.get(position).getOcurrenciasOperandos()+"\n";
                informacion+="L: "+DAO.listaMetricas.get(position).getLongitud()+"\n";
                informacion+="Voc: "+DAO.listaMetricas.get(position).getVocabulario()+"\n";
                informacion+="Vol: "+DAO.listaMetricas.get(position).getVolumen()+"\n";
                informacion+="D: "+DAO.listaMetricas.get(position).getDificultad()+"\n";
                informacion+="N: "+DAO.listaMetricas.get(position).getNivel()+"\n";
                informacion+="E: "+DAO.listaMetricas.get(position).getEsfuerzo()+"\n";
                informacion+="T: "+DAO.listaMetricas.get(position).getTiempo()+"\n";
                informacion+="B: "+DAO.listaMetricas.get(position).getBugs()+"\n";

                Toast.makeText(getApplicationContext(),informacion,Toast.LENGTH_LONG).show();

            }
        });
    }
}